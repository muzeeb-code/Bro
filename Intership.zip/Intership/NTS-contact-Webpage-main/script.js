function submitForm() {
  alert("Your message has been sent successfully!");
}
